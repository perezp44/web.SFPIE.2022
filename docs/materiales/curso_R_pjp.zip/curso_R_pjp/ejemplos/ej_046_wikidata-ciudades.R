# WIKIDATA, hay que conocerla mas!!!!
#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners
#- https://www.wikidata.org/wiki/Wikidata:Main_Page


library(tidyverse)
library(wikifacts) 
#-------------------------------------------------------------
#- Ejemplo: las ciudades más pobladas
#- ejemplo Wikidata: https://cran.r-project.org/web/packages/wikifacts/wikifacts.pdf
#- ejemplo: Wiidata: https://twitter.com/Wikimedia_mx/status/1332207421230632961
#Largest cities of the world: https://twitter.com/Wikimedia_mx/status/1332207421230632961
# https://query.wikidata.org/#%23Largest%20cities%20of%20the%20world%0ASELECT%20DISTINCT%20%3FcityLabel%20%3Fpopulation%20%3Fgps%0AWHERE%0A%7B%0A%20%20%3Fcity%20wdt%3AP31%2Fwdt%3AP279*%20wd%3AQ515%20.%0A%20%20%3Fcity%20wdt%3AP1082%20%3Fpopulation%20.%0A%20%20%3Fcity%20wdt%3AP625%20%3Fgps%20.%0A%20%20SERVICE%20wikibase%3Alabel%20%7B%0A%20%20%20%20bd%3AserviceParam%20wikibase%3Alanguage%20%22es%22%20.%0A%20%20%7D%0A%7D%0AORDER%20BY%20DESC(%3Fpopulation)%20LIMIT%20100

query <- 
'#Largest cities of the world
SELECT DISTINCT ?cityLabel ?countryLabel ?population ?gps
WHERE
{
  ?city wdt:P31/wdt:P279* wd:Q515 .
  ?city wdt:P1082 ?population .
  ?city wdt:P17 ?country .
  ?city wdt:P625 ?gps .
  SERVICE wikibase:label {
    bd:serviceParam wikibase:language "en" .
  }
}
ORDER BY DESC(?population) LIMIT 100'

#- mando la consulta a wikidata
df_ciudades_wiki <- wiki_query(query)
df <- df_ciudades_wiki
# rio::export(df_ciudades_wiki, "./pruebas/df_ciudades_wiki.rds")

#- recupero los datos obtenidos en la consulta a Wikidata
# df_orig <- readr::read_rds("./datos/df_ciudades_wikidata.rds")
#df <- df_orig #- voy a trabajar con df

#- hay q arreglar la columa gps
df <- df %>% mutate(gps = stringr::str_remove(gps, "Point\\(" ))
df <- df %>% mutate(gps = stringr::str_remove(gps, "\\)" ))

#- otra forma de arreglarlo, quizás mas fácil
df <- df_ciudades_wiki
df <- df %>% mutate(gps = stringr::str_remove(gps, "^......" ))
df <- df %>% mutate(gps = stringr::str_remove(gps, ".$" ))

#- separamos longitud y latitud
df <- df %>% tidyr::separate(gps, into = c("long", "lat"), sep = " ")


# convert coordinates to an sf object
library(sf)
df <- df %>% st_as_sf(coords = c("long", "lat"), crs = 4326)

library(leaflet)
leaflet(data = df) %>% addTiles() %>%
  addMarkers(popup = ~ as.character(population), label = ~ as.character(cityLabel))

#-- otro provider de tiles
leaflet(data = df) %>% addTiles() %>% addProviderTiles(providers$Stamen.Toner) %>% 
  addMarkers(popup = ~ as.character(population), label = ~ as.character(cityLabel))


#- Wikidata mola!!!  Wikidata, hay que conocerla más!!

#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- video más largito: https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners.webm


#- wikidata: https://www.wikidata.org/wiki/Wikidata:Main_Page
#- wikidata Queries: https://query.wikidata.org/
