#- desde el ayuntamiento de VLC \@EstadisticaVLC: un gráfico de facetas sobre el número de personas por hogar en #València por #distritos proveniente de los resultados del #BarómetroVLC de marzo de 2020.
#- https://twitter.com/EstadisticaVLC/status/1261258230262632448
#- codigo: https://github.com/estadisticavlc/RetoGraficos/blob/master/20200515%20Grafico%20con%20facetas.R

library(tidyverse)
library(here)
#----------------------------------------------------
#- datos de barometros de Valencia: https://www.valencia.es/es/cas/estadistica/barometro-municipal

datos <- rio::import("https://raw.githubusercontent.com/estadisticavlc/Datos/master/MicrodatosMarzo2020.csv")
datos <- datos %>% mutate(id_distrito = Districte, .before = Districte)

#- los nombres de los distritos
nombres_distrito <- c("Ciutat Vella","l'Eixample","Extramurs","Campanar",
                   "la Saïdia","el Pla del Real","l'Olivereta","Patraix",
                   "Jesús","Quatre Carreres","Poblats Marítims",
                   "Camins al Grau","Algirós","Benimaclet",
                   "Rascanya","Benicalap","Pobles del Nord",
                   "Pobles de l'Oest","Pobles del Sud")
datos$Districte <- nombres_distrito[datos$Districte]
datos$Districte <- factor(datos$Districte, levels = nombres_distrito)

#- el peso de cada observación
datos$PES <- as.numeric(as.character(datos$PES)) #- lo hacían así
datos <- datos %>% select(id_distrito, Districte, PES, everything())

#- pesos de los distritos
pesos_dt <- aggregate(PES ~ Districte, data = datos, sum)

#- P3 debe en nº de personas q viven contigo
pesos <- aggregate(PES ~ P3 + Districte, data = datos, sum)

datos_plot <- merge(pesos,pesos_dt,by = "Districte")
datos_plot$Porcentaje <- 100*datos_plot[,3]/datos_plot[,4]



# Dibujamos el gráfico con facetas
p <- ggplot(data = datos_plot, aes(x = P3, y = Porcentaje)) +  
  geom_bar(stat = "identity",fill = "#4781b3") +
  scale_x_continuous(breaks = c(0:10)) +
  facet_wrap(~ Districte, nrow = 4) +
  theme_bw() +
  labs(title="¿Cuántas personas viven en su casa contándose a usted?", 
       y="Porcentaje", 
       x="Personas", 
       caption="Fuente: Barómetro de Opinión Ciudadana de Marzo de 2020. Elaboración: Oficina d'Estadística. Ajuntament de València.")+
  theme(plot.title = element_text(size=10,hjust = 0.5,face="bold"),
        plot.caption = element_text(color = "black",face = "italic", size = 6, hjust = 0)) 

p
#ggsave(filename = paste0("20200515 Grafico con facetas.png"), p, width = 9, height = 5, dpi = 300, units = "in", device='png')


#- OK. con los mismos datos voy a calcular, en lugar del "histograma", la media y la voy a dibujar en un mapita
#curl::curl_download("https://github.com/estadisticavlc/Datos/raw/master/secciones.rda", destfile = "./datos/secciones_Valencia_ciudad.rda") #- los descargue el 20-sept-2021
load("./datos/secciones_Valencia_ciudad.rda") 
secciones_val <- secciones %>% sf::st_as_sf()
plot(secciones_val)

df <- datos %>% select(1:3, P3) %>% mutate(pes_x_P3 = PES*P3)

df <- df %>% group_by(id_distrito, Districte) %>% 
             summarise(media_P3 = mean(pes_x_P3) )


#- Ok, ya tengo la media (ponderada) hay que juntar con los polígonos de los distritos
#- lo que pasa es que parece que hay datos de distrito y sección. Ya arreglaré y haré el mapa
