#- Objetivo
#- Vamos a hacer un race-barchart con datos covid
#-  para ello utilizaremos el pkg "robservable": https://cran.r-project.org/web/packages/robservable/index.html
#- con este pkg se pueden hacer algunas visualizaciones dinámicas: https://cran.r-project.org/web/packages/robservable/vignettes/gallery.html


library(tidyverse)
library(robservable)   #- install.packages("robservable")
library(coronavirus)   #- devtools::install_github("RamiKrispin/coronavirus")


# Load data --------------------------------------------------------------------
#- en lugar de cargar los datos directamente de la Jhon Hopkins, ahora
#- ahora vamos a usar un nuevo pkg que hace tidy los datos de la Jhon Hopkins:
#- la web del pkg:https://ramikrispin.github.io/coronavirus/index.html

# library(coronavirus) #- devtools::install_github("RamiKrispin/coronavirus")
# update_dataset()
# df <- refresh_coronavirus_jhu() #- datos de coronavirus de la Jhon Hopkins, hechos tidy x ramikrispin.github.io

df <- coronavirus::coronavirus
#- rio::export(df, "./datos/covid_pkg_2021-10-17.rds")
str(df)
df_aa <- pjpv2020.01::pjp_f_unique_values(df)


#------------ Pb con regiones --------------------------------------------------
#- había un pb con q resulta que haya países q tienen info por provincias y otros q no
#- concretamente hay 8 paises con informacion detallada x regiones ("Canada", "United Kingdom", "China"      "Netherlands", Australia", "New Zealand")  
#- de estos 8 paises hay 5 q tb tienen informaciona de "deaths" agregada para el pais, PERO ...
#- PERO hay 3 paises: Canada, China y Australia q no tienen info de deaths agregada, solo lo tienen para las provincioas, asi que hay que agregar
#- asi es como ví q pasaba lo de las provincias/paises
zz <- df %>% filter(country == "Canada") %>% filter(is.na(province))
df_x <- df %>% filter(!is.na(province)) %>% 
      filter(type == "death") %>%  #- seleccionamos los datos de deaths (hay confirmed y recovered)
      select(-lat, -long) %>%      #- quito 2 variable q no necesito (lat y long)
      distinct(country) %>% pull   #- 8 países con info desagregadas

df_xx <- df %>% filter(country %in% df_x) %>% #- solo los países q tienen info x regiones
  filter(is.na(province)) %>% 
  filter(type == "death") %>% 
  distinct(country) %>% pull   #- 5 países con deaths a nivel nacional, así q 3 no lo tienen: Canada, China, Australia
#------------

#- arreglo el dataframe ----------------------
df <- df %>% 
  filter(type == "death") %>%  #- seleccionamos los datos de deaths (hay confirmed y recovered)
  select(-lat, -long) %>%   #- quito 3 variable q no necesito (lat y long) 
  select(-type) %>%         #- quito type xq me concentro en "deaths" 
  select(-c(uid, code3, combined_key, continent_name))  #- me sobran códigos

  str(df)
#- separo los datos de los 3 países q solo tienen datos de provincias
zz_3_paises <- df %>% 
  filter(country %in% c("Canada", "China", "Australia")) %>%    #- 3 países raros
  group_by(date, country, iso2, iso3, continent_code) %>%                           
  summarise(cases = sum(cases, na.rm = TRUE)) %>% 
  mutate(province = NA, .after = date) %>% ungroup() %>% 
  relocate(cases, .after = country)
#- tb hay q sumar la poblacion 
zz_3_paises_pob <- df %>% 
  filter(country %in% c("Canada", "China", "Australia")) %>%   #- 3 países raros
  filter(date == "2021-10-16")  %>% #- solo una fecha
  group_by(country) %>%      #- no puedo hacerlo x iso2 etc... xq esta Macao y HongKong               
  summarise(population = sum(population, na.rm = TRUE)) 
  
#- tengo q añadir la población a los 3 paises
zz_3_paises <- left_join(zz_3_paises, zz_3_paises_pob) %>% 
               relocate(population, .after =iso3)

#- añado los datos para el conjunto del país de los 3 países raros
df <- bind_rows(df, zz_3_paises)

#- quito los datos de las regiones
df <- df %>% 
  filter(is.na(province)) %>%  #- dejo solo los totales para los países
  select(-province)            #- ya no hace falta province

#- calculo las muertes acumuladas
df <- df %>% 
  group_by(country) %>% 
  arrange(date) %>% 
  mutate(cases_ac = cumsum(cases), .after = cases) %>% #- %>%  acumulo las deaths
  mutate(date = as.character(date)) %>%        #- creo q hace falta para meterlo en robservable
  ungroup()
str(df)

df <- df %>% 
  mutate(cases_ac_per = (cases_ac/population)*100000, .after = cases_ac)

#- aún hay q quitar Canada y NA // y CHina y HK y MO en iso2
df <- df %>%
  filter(!(country == "Canada" & is.na(iso2)))  %>%  
  filter(!(country == "China" & iso2 == "HK"))  %>%  
  filter(!(country == "China" & iso2 == "MO"))    
  

#- some checks
zz <- df %>% filter(date == "2021-09-18")
zz <- df %>% filter(country == "Spain")    #- bueno, hay algunos saltos y correciones

#- preparando las v. para robservable---
#- creo q las variables se han de llamar de una determinada manera
#- las fechas deben estar en v. de texto llamada "date": ok


df_ok <- df %>% 
  rename(value = cases_ac_per) %>% 
  rename(id = country) %>% 
  mutate(value = as.numeric(value)) %>% 
  select(id, date, value) %>% 
  group_by(id, date) %>% arrange(date) %>% 
  ungroup()

#- voy a dejar cada periodo los 12 peores países
df_ok_7 <- df_ok %>% 
  group_by(date) %>%  
  slice_max(value, n = 12) %>% 
  ungroup()
  


# Generate robservable chart ---------------------------------------------------
#- puedes grabarlo como un html

#- el dashborad: https://ramikrispin.github.io/coronavirus_dashboard/
#- source code: https://github.com/RamiKrispin/coronavirus_dashboard


robservable(
  "https://observablehq.com/@juba/bar-chart-race",
  include = c("viewof date", "chart", "draw", "styles"),
  hide = "draw",
  input = list(
    data = df_ok,   #- usamos df_ok
    title = "COVID-19 deaths",
    subtitle = "Cumulative number of COVID-19 deaths by country (per 100.000 inhabitants)",
    source = "Source : Johns Hopkins University"
  ),
  width = 700,
  height = 710
)


