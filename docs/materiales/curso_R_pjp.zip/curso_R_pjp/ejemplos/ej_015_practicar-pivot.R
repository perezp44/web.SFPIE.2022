#- ej para pivot_
#- https://heads0rtai1s.github.io/2019/11/07/tidy-curly-pivot-leaflet/   el ejemplo lo hace con squirels
library(tidyverse)
library(palmerpenguins)
library(kableExtra)

#- calculas nº de pinguinos por especie y genero
tabla_long <- penguins %>% group_by(species, sex) %>% count() 
kable(tabla_long) %>% kable_styling()

#- lo pasamos a ancho
tabla_wide <- tabla_long %>% pivot_wider(names_from = sex, values_from = n)
kable(tabla_wide) %>%  kable_styling()

tabla_long_2 <- tabla_wide %>% pivot_longer(cols = 2:4, names_to = "sex", values_to = "NN")
