#- OBJETIVO: tablas de frecuencias simples

#- Con R-base
table(iris$Species)
table(iris$Sepal.Length)


#- Hacer tablas de frecuencias con tidyverse
iris %>% group_by(Species) %>% count()   #- Species es categórica
iris %>% group_by(Sepal.Length) %>% count()   #- Sepal.Length es continua



#- Hacer una tabla de frecuencias entre una variable continua (que discretizaremos) y una variable categórica
library(tidyverse)
iris %>% group_by(Sepal.Length, Species) %>% count()   #- Sepal.Length  es variable continua. Species es categórica


iris %>% mutate(v_discretizada = cut(Sepal.Length, breaks = 3)) %>% #- Discretizamos Sepal.Lenght. El rango se parte con 3 puntos de corte, nos saldrán 4 grupos
  group_by(v_discretizada, Species) %>% count()

iris %>% mutate(v_discretizada = cut(Sepal.Length, breaks = quantile(Sepal.Length, probs = seq(0.25, 0.50, 0.75)))) %>% #-ahora los puntos de corte seran los cuartiles
  group_by(v_discretizada, Species) %>% count()

#- El "problema" es que la "tabla" esta en long format
#- para pasarlo al formato mas visual (wide format): spread()

iris %>% mutate(v_discretizada = cut(Sepal.Length, breaks = quantile(Sepal.Length, probs = seq(0.25, 0.50, 0.75)))) %>% #-ahora los puntos de corte seran los cuartiles
  group_by(v_discretizada, Species) %>% count() %>% 
  spread(v_discretizada, n)

#- Evidentemente si las 2 variables fuesen categoricas seria mas facil, ya que no hay que discretizar

iris %>% group_by(Species) %>% count()   #- Sepal.Length  es variable continua. Species es categórica

#- para tablas sencillas de count y % es muy fácil usar janitor::tabyl()
