#- Padrón de españoles residentes en el extranjero. PERE. 1 de enero de 2021
#- https://ine.es/dynt3/inebase/es/index.htm?padre=7776&capsel=7777
#- vamos a trabajar la primera tabla: Población por país de residencia, sexo y grupos de edad (quinquenales). 

library(tidyverse)

#- Rtdos 2021  -----------
#- Resultados detallados a 1 de enero de 2021 (6 tablas). (se publicaron en 18 de marzo de 2021)

# tabla	1.1 Población por país de residencia, sexo y grupos de edad (quinquenales).
url <- "https://ine.es/jaxi/files/_px/es/px/t20/p85001/a2021/l0/01001.px?nocab=1"
df_orig <- pxR::read.px(url) %>% as.data.frame()
zz <- pjpv.curso.R.2022::pjp_valores_unicos(df_orig)


#- https://ine.es/dynt3/inebase/es/index.htm?padre=3670&capsel=3672
# tabla 1.1 Población Española residente en el extranjero por país de residencia, sexo y año de referencia --------
url <- "https://ine.es/jaxi/files/_px/es/px/t20/p85001/serie/l0/01001.px?nocab=1"
df_orig <- pxR::read.px(url) %>% as.data.frame()


df <- df_orig %>% janitor::clean_names()
zz <- pjpv.curso.R.2022::pjp_valores_unicos(df_orig)
names(df)

df <- df %>% 
  dplyr::rename(year = ano) %>% 
  dplyr::rename(pais = pais_de_residencia) 


#- guardo el nº total de españoles en el extranjero
df_totales <- df %>% filter(stringr::str_detect(pais, "^\\d"))    #- guardo los totales (empiezan por un nº)  
df_totales_2 <- df %>% filter(stringr::str_detect(pais, "^[0-9]"))
rm(df_totales_2)

vv_valores <- df_totales %>% distinct(pais) %>% pull

#- las distintas categorias de TOTALES:  1. TOTAL PAÍSES (TODOS LOS CONTINENTES) 2 TOTAL EUROPA etc ....

df_totales <- df_totales %>% 
  mutate(continente = case_when(
    pais == vv_valores[1] ~ "mundo",
    pais == vv_valores[2] ~ "europa",
    pais == vv_valores[3] ~ "africa",
    pais == vv_valores[4] ~ "america",
    pais == vv_valores[5] ~ "asia",
    pais == vv_valores[6] ~ "oceania")) %>% 
  select(-pais)

#- si quisiera ver los totales mejor
df_totales_w <- df_totales %>% pivot_wider(names_from = continente, values_from = value, names_prefix = "value_")


#- continúo (ahora quito los totales xq ya los he guardado)
df <- df %>% 
  filter(!stringr::str_detect(pais, "^\\d"))    #- quito los totales (empiezan por un nº)    
zz <- pjpv2020.01::pjp_f_valores_unicos(df, nn_pjp = 70)


#- ahora tengo que unir df con df_totales
#- OK; p.ejemplo, en Almeria hay 3077 q viven en Alemania, sobre un total de 49.876; osea, un 6,16%
df_x <- left_join(df, df_totales_w)



#- pongo codigos iso
df <- df %>% 
  mutate(iso2 = countrycode::countrycode(sourcevar = pais, 
                                         origin = "country.name", 
                                         destination = "iso2c", warn = FALSE), 
         .after = pais) 
  





# tabla 1.4 Población Española residente en el extranjero por provincia de inscripción, grupos de edad quinquenales y año de referencia -------------
url <- "https://ine.es/jaxi/files/_px/es/px/t20/p85001/serie/l0/01004.px?nocab=1"
df_orig <- pxR::read.px(url) %>% as.data.frame()
df <- df_orig %>% janitor::clean_names()
zz <- pjpv2020.01::pjp_f_valores_unicos(df, nn_pjp = 70)
names(df)

