#- ejemplo simple para familiarizarse un poco con el entorno de RStudio y la sintaxis de R
#- cargaremos unos datos de internet y haremos algunos gráficos

#- cargamos paquetes en memoria
library(tidyverse)
library(ggpol)   #- devtools::install_github('erocoar/ggpol')


df_parlam <- tibble(
  parties = factor(c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos"),
                   levels = c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos")),
  seats   = c(200, 46, 92, 80, 153, 69, 67, 2),
  colors  = c("black", "blue", "lightblue", "yellow", "red","purple", "green", "grey")   )


ggplot(df_parlam) +
  geom_parliament(aes(seats = seats, fill = parties), color = "black") +
  scale_fill_manual(values = df_parlam$colors, labels = df_parlam$parties) +
  coord_fixed() +
  theme_void()


