#- contrastar si la media de una variable es igual en dos grupos
library(tidyverse)
aa <- mtcars %>% mutate(wt_group = wt > mean(wt)) #- defino 2 grupos (observaciones por encima y debajo de la media de wt)

# Ahora con la función t.test() hago contraste para ver si la media de `mpg` es igual en los 2 grupos definidos por wt_group

aa %>% t.test(mpg ~ wt_group, data = .)  #- tabla de resultados

aa %>% t.test(mpg ~ wt_group, data = .) %>% broom::tidy() #- resultados tidy


#- todo junto
bb <- mtcars %>% mutate(wt_group = wt > median(wt)) %>% 
  t.test(mpg ~ wt_group, data = .) %>% broom::tidy() #- todo junto

