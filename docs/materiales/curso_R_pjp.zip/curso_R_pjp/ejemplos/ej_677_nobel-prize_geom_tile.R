#- ejemplo_nobeles: https://twitter.com/tanya_shapiro/status/1469417847231332357
#- code: https://github.com/tashapiro/DataViz/blob/main/noble-prize-laureates/noble-prize-laureates.R
library(httr)
library(jsonlite)
library(tidyverse)

#- get laureate data with nobel prize API
# res1 <- GET('http://api.nobelprize.org/2.1/laureates?limit=1000')
# json_laureate <- fromJSON(rawToChar(res1$content))
# laureate <- json_laureate$laureates #- [[1]]
# rio::export(laureate, "./datos/nobeles_ej_1002_2022.rds")

#- importo datos:
laureate <- rio::import("./datos/nobeles_ej_1002_2022.rds")


#- create data of noble laureates
df_laureate <- laureate %>%
  unnest(c(fullName, givenName, familyName, birth),  names_repair = tidyr_legacy) %>%
  select(id, en, en1, en2, gender, date, place) %>%
  rename(id="id",
         last_name = "en",
         first_name = "en1",
         full_name = "en2",
         birth_date = "date") %>%
  unnest(place) %>%
  unnest(c(cityNow, countryNow), names_repair = tidyr_legacy) %>%
  select(id, full_name, first_name, last_name, birth_date, gender, en, en1) %>%
  rename(birth_city = "en",
         birth_country = "en1")

#create data set of awards (noble prizes)
df_prize <- laureate %>%
  select(id, nobelPrizes) %>%
  unnest(c(nobelPrizes), repair = "universal") %>%
  select(id, awardYear, category)%>%
  unnest(c(category)) %>%
  select(id, awardYear, en) %>%
  rename(laureate_id = "id",award_year = "awardYear", category = "en")

#combine the two datasets
df_prize_laureate <- left_join(df_prize, df_laureate, by = c("laureate_id"="id"))

#convert year to integer
df_prize_laureate$award_year<-as.integer(df_prize_laureate$award_year)
df_prize_laureate$count <- 1




#reshape data
df_grouping <- df_prize_laureate %>%
  tidyr::complete(category = unique(df_prize_laureate$category), award_year = 1901:2021) %>%
  group_by(category, award_year) %>%
  summarise(total_count = sum(count),
            male_count = sum(count[gender=="male"]),
            female_count = sum(count[gender=="female"])) %>%
  mutate(grouping = case_when(
      female_count == total_count ~ "Female",
      male_count   == total_count ~ "Male",
      female_count >0             ~ "Mixed Team")) %>% 
  mutate(award_decade = round(award_year / 10) * 10) %>% 
  mutate(year_split = case_when(
      award_year >= 1981 ~ "1981-2021",
      award_year >= 1941 ~ "1941-1980",
      award_year >= 1901 ~ "1901-1940") )

#categories
category_list = c("Physiology or Medicine", "Physics", "Chemistry", "Literature", "Peace", "Economic Sciences")
#factor categories, i.e. Economic Sciences not introduced until later
df_grouping$category <- factor(df_grouping$category, levels = rev(category_list))

#palette
pal <- c('#D90368', '#2274A5', '#F1C40F')

#plot
ggplot(df_grouping, aes(x = award_year, y = category, fill = grouping)) +
  geom_tile(colour = "white", width = .9, height = .9) + 
  scale_fill_manual(values = pal, na.value = "grey85",
                    guide = guide_legend(title.position = "top", title.hjust = 0.5)) +
  facet_wrap( ~ year_split, ncol = 1, scales = "free_x")+
  labs(title = "NOBLE PRIZE LAUREATES - CATEGORY, YEAR, & GENDER",
       caption = "Data from Noble Prize API | Chart @tanya_shapiro",
       subtitle = 'Note: Some categories and years have more than one recipient, "Mixed" denotes a team with male and female laureates',
       x = "Year",
       y = "Category",
       fill = "Recipient Gender") +
  theme_void() +
  theme(text = element_text(family = "Gill Sans"),
    legend.position = "top",
    plot.title = element_text(hjust = 0.5, family = "Gill Sans Bold", size = 18, vjust = 5),
    plot.subtitle = element_text( hjust = 0.5, vjust=6),
    axis.title.x = element_text(family = "Gill Sans"),
    axis.text = element_text(family = "Gill Sans"),
    axis.text.y = element_text(hjust = 1),
    strip.text.x = element_text(size = 12, family = "Gill Sans"),
    plot.caption = element_text(size = 10, hjust = 0.95),
    plot.margin = unit(c(1.1, 0.8, 0.8, 0.8), "cm"),
    legend.spacing.x = unit(0.8, 'cm'),
    legend.box.margin = margin(0,0,0.25,0))

#ggsave("noble-prize-laureates.jpeg", height=8, width=12)